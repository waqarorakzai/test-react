# bio-foul > 2024-04-01 10:14am
https://universe.roboflow.com/biofouling-9onuy/bio-foul

Provided by a Roboflow user
License: CC BY 4.0

